import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.Stopwatch;

public class b3 {
    public static double timeTrial(int N) {
        int MAX = 1000000;
        int[] a = new int[N];
        for (int i = 0; i < N; i++) {
            a[i] = StdRandom.uniformInt(-MAX, MAX);
        }
        Stopwatch timer = new Stopwatch();
        ThreeSum_1_4_2.count(a);
        return timer.elapsedTime();
    }

    public static void draw(int maxN) {
        StdDraw.setCanvasSize(800, 800);
        StdDraw.setXscale(0, maxN * 1.2);
        StdDraw.setYscale(0, 50.0);
        StdDraw.setPenRadius(0.01);
        
        int prevN = 250;
        double prevTime = timeTrial(prevN);
        
        for (int N = 500; N <= maxN; N += N) {
            double time = timeTrial(N);
            StdDraw.setPenColor(StdDraw.RED);
            StdDraw.point(N, time);
            if (prevN > 0) {
                StdDraw.line(prevN, prevTime, N, time);
            }
            prevN = N;
            prevTime = time;
        }
    }

    public static void main(String[] args) {
        draw(8000);
    }
}