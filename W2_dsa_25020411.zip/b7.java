import java.util.Arrays;

public class b7 {
    public static int countEqualPairs(int[] a) {
        Arrays.sort(a);
        int pairs = 0;
        int currentCount = 1;

        for (int i = 1; i < a.length; i++) {
            if (a[i] == a[i - 1]) {
                currentCount++;
            } else {
                if (currentCount > 1) {
                    pairs += (currentCount * (currentCount - 1)) / 2;
                }
                currentCount = 1;
            }
        }
        if (currentCount > 1) {
            pairs += (currentCount * (currentCount - 1)) / 2;
        }

        return pairs;
    }
}